<!DOCTYPE HTML>
<!--[if IE 6]>
<html id="ie6" class="ie ie6 lt-ie9">
<![endif]-->
<!--[if IE 7]>
<html id="ie7" class="ie ie7 lt-ie9">
<![endif]-->
<!--[if IE 8]>
<html id="ie8" class="ie ie8 lt-ie9">
<![endif]-->
<!--[if gte IE 9]>
<html class="ie ie9">
<![endif]-->
<!--[if !(IE)]><!-->
<html>
<!--<![endif]-->
<head>
	<meta http-equiv='Pragma' content='no-cache' />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="author" content="情人节,表白程序,情人节表白程序,自动生成表白程序,自动表白程序">
	<meta name="description" content="这是一个自动生成表白页面的程序，模版由jianghongfei.com.cn原创，麦葱(www.yuxiaoxi.com)做二次开发，仅限娱乐，不得用于商业用途">
	<title>情人节自动生成表白程序</title>
	<link rel="stylesheet" href="css/all.min.css">
</head>
<body>
	<div class="flowtime">
		<div class="ft-section section-1" data-id="section-1">
			<div id="/section-1/page-1" class="ft-page page-1" data-id="page-1">
				<p class="text1"><span id="text-75" contenteditable="true">小明</span> ❤ <span id="text-76" contenteditable="true">小红</span> <span id="text-77" contenteditable="true">一生一世</span></p>
				<p class="text2">按键盘 "↓" <span id="text-78" contenteditable="true">开始倾听我的表白</span></p>
			</div>
			<div id="/section-1/page-2" class="ft-page page-2" data-id="page-2">
				<p class="top-text" id="text-1" contenteditable="true">过去的小明一直是一个人生活，享受着孤独，也憧憬着爱情。</p>
				<img src='img/iali63.jpg'  alt="过去的小明一直是一个人生活，享受着孤独，也憧憬着爱情。" />
			</div>
			<div id="/section-1/page-3" class="ft-page page-3 left-img" data-id="page-3">
				<h2 class="text" id="text-2" contenteditable="true">一个人的长廊</h2>
				<img src='img/iali35.jpg'  alt="一个人的长廊"/>
			</div>
			<div id="/section-1/page-4" class="ft-page page-4 full-img" data-id="page-4">
				<h2 class="center-text" id="text-3" contenteditable="true">一个人的山岗</h2>
				<img src='img/iali6.jpg'  alt="一个人的山岗" />
			</div>
		</div>
		<div class="ft-section section-2" data-id="section-2">
			<div id="/section-2/page-1" class="ft-page page-5 full-img" data-id="page-1">
				<h2 class="center-text" id="text-4" contenteditable="true">一个人的地铁</h2>
				<img src='img/iali19.jpg'  alt="一个人的山岗" />
			</div>
			<div id="/section-2/page-2" class="ft-page page-6" data-id="page-2">
				<h2 class="center-text" id="text-5" contenteditable="true">一个人的游乐场</h2>
				<img src='img/iali29.jpg' alt="一个人的游乐场"/>
			</div>
			<div id="/section-2/page-3" class="ft-page page-7" data-id="page-3">
				<h3 id="text-6" contenteditable="true">但他依然乐观，微笑着，等待着</h3>
				<img src='img/iali60.jpg'  alt="但他依然乐观，微笑着，等待着"/>
			</div>
			<div id="/section-2/page-4" class="ft-page page-8 full-img" data-id="page-4">
				<h3 id="text-7" contenteditable="true">生活难免有风风雨雨</h3>
				<img src='img/iali51.jpg' alt="生活难免有风风雨雨" />
			</div>
			<div id="/section-2/page-5" class="ft-page page-9" data-id="page-5">
				<h3 id="text-8" contenteditable="true">他总是能够轻松的应对</h3>
				<img src='img/iali5.jpg' />
			</div>
			<div id="/section-2/page-6" class="ft-page page-10" data-id="page-6">
				<h3 id="text-9" contenteditable="true">并且面带阳光、自信的笑容</h3>
				<img src='img/iali22.jpg' />
			</div>
		</div>
		<div class="ft-section section-3" data-id="section-3">
			<div id="/section-3/page-1" class="ft-page page-11 full-img" data-id="page-1">
				<h3 id="text-10" contenteditable="true">生活也不会总是一帆风顺</h3>
				<img src='img/iali24.jpg'  />
			</div>
			<div id="/section-3/page-2" class="ft-page page-12" data-id="page-2">
				<h3><span id="text-11" contenteditable="true">但他每次都能勇敢的面对</span><br /><span id="text-12" contenteditable="true">随时准备接受生活的挑战</span></h3>
				<img src='img/iali25.jpg' />
			</div>
			<div id="/section-3/page-3" class="ft-page page-13" data-id="page-3">
				<img src='img/iali64.jpg' alt='可是小明的爱情又在哪里呢？' />
				<h3 id="text-13" contenteditable="true">可是小明的爱情又在哪里呢？</h3>
			</div>
			<div id="/section-3/page-4" class="ft-page page-14 left-img" data-id="page-4">
				<h3 id="text-14" contenteditable="true">在镜子里面吗？他不敢相信</h3>
				<img src='img/iali46.jpg' />
			</div>
			<div id="/section-3/page-5" class="ft-page page-15 left-img" data-id="page-5">
				<h3><span id="text-15" contenteditable="true">他去问大树，我的爱情在哪里？</span><br /><span id="text-16" contenteditable="true">大树告诉他，也许就在不远的地方</span></h3>
				<img src='img/iali45.jpg' />
			</div>
			<div id="/section-3/page-6" class="ft-page page-16 left-img" data-id="page-6">
				<h3><span id="text-17" contenteditable="true">于是，小明一个人继续向前走</span><br /><span id="text-18" contenteditable="true">走在茫茫的雪地上</span></h3>
				<img src='img/iali66.jpg' />
			</div>
			<div id="/section-3/page-7" class="ft-page page-17 top-text" data-id="page-7">
				<h3 id="text-19" contenteditable="true">直到有一天小明与小红相遇了</h3>
				<img src='img/iali16.jpg' />
			</div>
		</div>
		<div class="ft-section section-4" data-id="section-4">
			<div id="/section-4/page-1" class="ft-page page-18 full-img" data-id="page-1">
				<p class="text" id="text-20" contenteditable="true">小明喜欢小红，因为小红的出现，小明脸上有了更加灿烂的笑容</p>
				<img src='img/iali11.jpg'  />
			</div>
			<div id="/section-4/page-2" class="ft-page page-19" data-id="page-2">
				<h3 id="text-21" contenteditable="true">可是小红会喜欢小明吗？</h3>
				<img src="img/iali75.jpg" />
			</div>
			<div id="/section-4/page-3" class="ft-page page-20" data-id="page-3">
				<img src='img/iali59.png' />
				<h3 id="text-22" contenteditable="true">终于有一天，小明鼓起了勇气</h3>
				<img src='img/iali9.jpg' />
			</div>
			<div id="/section-4/page-4" class="ft-page page-21" data-id="page-4">
				<h3 id="text-23" contenteditable="true">小明好高兴</h3>
				<img src='img/iali59.png' />
			</div>
			<div id="/section-4/page-5" class="ft-page page-22 left-img" data-id="page-5">
				<h3 id="text-24" contenteditable="true">每天小明都会去找小红</h3>
				<img src='img/iali4.jpg' />
			</div>
			<div id="/section-4/page-6" class="ft-page page-23 left-img" data-id="page-6">
				<h3 id="text-25" contenteditable="true">然后两个人一起出去玩</h3>
				<img src='img/iali44.jpg' />
			</div>
			<div id="/section-4/page-7" class="ft-page page-24 full-img" data-id="page-7">	
				<h3 id="text-26" contenteditable="true">晚上小明会把小红送回家</h3>
				<img src='img/iali32.jpg' />
			</div>
		</div>
		<div class="ft-section section-5" data-id="section-5">
			<div id="/section-5/page-1" class="ft-page page-25 left-img" data-id="page-1">
				<h3><span id="text-27" contenteditable="true">直到很晚</span><br /><span id="text-28" contenteditable="true">小明才会一个人回家</span></h3>
				<img src='img/iali37.jpg' />
			</div>
			<div id="/section-5/page-2" class="ft-page page-26 top-text" data-id="page-2">
				<h3 id="text-29" contenteditable="true">然后高兴地进入梦乡，希望梦到小红</h3>
				<img src='img/iali10.gif' />
			</div>
			<div id="/section-5/page-3" class="ft-page page-27" data-id="page-3">
				<h3 id="text-30" contenteditable="true">小明很快就成为了小红的逛街助手</h3>
				<img src='img/iali67.jpg'  />
			</div>
			<div id="/section-5/page-4" class="ft-page page-28" data-id="page-4">
				<h3 id="text-31" contenteditable="true">小明和小红一起去了好多地方玩</h3>
				<img src='img/iali40.jpg' />
			</div>
			<div id="/section-5/page-5" class="ft-page page-29" data-id="page-5">
				<h3 id="text-32" contenteditable="true">小明也和小红一样成为了一个吃货</h3>
				<img src='img/iali12.jpg' />
			</div>
			<div id="/section-5/page-6" class="ft-page page-30" data-id="page-6">
				<h3 id="text-33" contenteditable="true">后来，他们搬到了一起</h3>
				<img src='img/iali76.gif' />
			</div>
			<div id="/section-5/page-7" class="ft-page page-31" data-id="page-7">
				<h3 id="text-34" contenteditable="true">于是小明开始学习新的技能</h3>
				<img src='img/iali77.jpg' />
			</div>
		</div>
		<div class="ft-section section-6" data-id="section-6">
			<div id="/section-6/page-1" class="ft-page page-32" data-id="page-1">
				<h3 id="text-35" contenteditable="true">煮饭</h3>
				<img src='img/iali62.jpg'  />
			</div>
			<div id="/section-6/page-2" class="ft-page page-33 top-text" data-id="page-2">
				<h3 id="text-36" contenteditable="true">每天早上，他们吃着自己做的美食</h3>
				<img src='img/iali3.jpg' />
			</div>
			<div id="/section-6/page-3" class="ft-page page-34 left-img" data-id="page-3">
				<h3 id="text-37" contenteditable="true">然后在同一个站台，高高兴兴的一起上班</h3>
			</div>
			<div id="/section-6/page-4" class="ft-page page-35" data-id="page-4">
				<h3><span id="text-38" contenteditable="true">小明感觉自己好幸福。</span><br /><span id="text-39" contenteditable="true">因为自己有了家</span><br /><span id="text-40" contenteditable="true">那个有小红在的地方</span></h3>
				<img src='img/iali8.gif' />
			</div>
			<div id="/section-6/page-5" class="ft-page page-36 full-img" data-id="page-5">
				<h3 id="text-41" contenteditable="true">他们偶尔也会吵架</h3>
				<img src='img/iali31.jpg' />
			</div>
			<div id="/section-6/page-6" class="ft-page page-37 left-img" data-id="page-6">
				<h3 id="text-42" contenteditable="true">小明不想这样</h3>
				<img src='img/iali49.jpg' />
			</div>
			<div id="/section-6/page-7" class="ft-page page-38 bottom-text" data-id="page-7">
				<img src='img/iali21.jpg' />
				<h3 id="text-43" contenteditable="true">一定是我有什么做的不对，小明在想</h3>
			</div>
		</div>
		<div class="ft-section section-7" data-id="section-7">
			<div id="/section-7/page-1" class="ft-page page-39 left-img" data-id="page-1">
				<h3 id="text-44" contenteditable="true">如果没有小红在身边，窗外就没有风景</h3>
				<img src='img/iali2.jpg' />
			</div>
			<div id="/section-7/page-2" class="ft-page page-40" data-id="page-2">
				<h3 id="text-45" contenteditable="true">如果没有小红在身后</h3>
				<img src='img/iali14.jpg'  />
			</div>
			<div id="/section-7/page-3" class="ft-page page-41" data-id="page-3">
				<img src='img/iali30_1.jpg' class='img1'/>
				<img src='img/iali30_2.jpg' class='img2'/>
				<h3 id="text-46" contenteditable="true"> 小明又怎会飞的更高更远</h3>
			</div>
			<div id="/section-7/page-4" class="ft-page page-42" data-id="page-4">
				<h3><span id="text-47" contenteditable="true">小明不想这样。他要为小红改变自己</span><br /><span id="text-48" contenteditable="true">小红说她喜欢狮子座的人，于是小明许下愿望</span></h3>
				<img src='img/iali69.jpg'  />
			</div>
			<div id="/section-7/page-5" class="ft-page page-43" data-id="page-5">
				<img src='img/iali42.jpg' />
				<h3 id="text-49" contenteditable="true">我愿为你变成狮子座</h3>
			</div>
			<div id="/section-7/page-6" class="ft-page page-44 left-img" data-id="page-6">
				<h3><span id="text-50" contenteditable="true">爱情就像花草一样</span><br /><span id="text-51" contenteditable="true">需要用包容来浇灌</span></h3>
				<img src='img/iali0.jpg' />
			</div>
			<div id="/section-7/page-7" class="ft-page page-45 left-img" data-id="page-7">
				<h3><span id="text-52" contenteditable="true">再到后来，小红要过生日了</span><br /><span id="text-53" contenteditable="true">小明开始为小红准备礼物</span></h3>
				<img src='img/iali18.jpg' />
			</div>
		</div>
		<div class="ft-section section-8" data-id="section-8">
			<div id="/section-8/page-1" class="ft-page page-46" data-id="page-1">
				<img src='img/iali57.gif' />
				<h3>
					<span id="text-54" contenteditable="true">看着礼物一件件准备好了</span>
					<span id="text-55" contenteditable="true">小明好开心</span>
					<span id="text-56" contenteditable="true">因为他想象着小红收到礼物时</span>
					<span id="text-57" contenteditable="true">开心的样子</span>
				</h3>
			</div>
			<div id="/section-8/page-2" class="ft-page page-47 top-text" data-id="page-2">
				<img src='img/iali58.jpg' />
				<h3>
					<span id="text-58" contenteditable="true">想想后面还有一辈子</span>
					<span id="text-59" contenteditable="true">小明好开心</span>
					<span id="text-60" contenteditable="true">因为可以和小红</span>
					<span id="text-61" contenteditable="true">去全世界好多地方玩</span></h3>
				
			</div>
			<div id="/section-8/page-3" class="ft-page page-48 left-img" data-id="page-3">
				<p><span id="text-62" contenteditable="true">小明也会继续努力</span><br /><span id="text-63" contenteditable="true">为了他和小红的梦之城堡</span></p>
				<img src='img/iali65.jpg'  />
			</div>
			<div id="/section-8/page-4" class="ft-page page-49 full-img" data-id="page-4">
			<img src='img/iali71.jpg' />
				<p class="text">
					<span class='text' id="text-64" contenteditable="true">小明很幸福，因为他找到了小红。他相信后面的每天都会是快乐的</span><br />
					<span class='text' id="text-65" contenteditable="true">简简单单，体会着与小红在一起的每一个刻</span>
				</p>
			</div>
			<div id="/section-8/page-5" class="ft-page page-50" data-id="page-5">
				<p class='text' id="text-66" contenteditable="true">后来的一天，小红说她不敢坐山车了，于是小明就带她到别的地方玩。这只是他们幸福生活中的一件小事，小到无法引起别人的注意。可这是属于小明和小红的幸福生活。</p>
				<img src='img/iali50_1.jpg' class='img1' />
				<img src='img/iali50_2.jpg' class='img2' />
			</div>
			<div id="/section-8/page-6" class="ft-page page-51" data-id="page-6">
				<p>
					<span id="text-67" contenteditable="true">小红：永远有多远？</span><br />
					<span id="text-68" contenteditable="true">小明：比时间多一秒就是永远，我会永远爱你</span><br />
					<span id="text-69" contenteditable="true">小红：世界有多大？</span><br />
					<span id="text-70" contenteditable="true">小明：你走到哪里，世界就有多大</span>
					</p>
			</div>
		</div>
		<div class="ft-section section-9" data-id="section-9">
			<div id="/section-9/page-1" class="ft-page page-52 full-img" data-id="page-1">
				<h3 id="text-71" contenteditable="true">愿得一人心，白首不相离</h3>
				<img src='img/iali20.jpg'  />
			</div>
			<div id="/section-9/page-2" class="ft-page page-53" data-id="page-2">
				<img src='img/iali68.jpg' alt='happy birthday' />
				<h3 id="text-72" contenteditable="true">情人节快乐</h3>
			</div>
			<div id="/section-9/page-3" class="ft-page page-54 center-img" data-id="page-3" >
				<div class="center-img">I love you</div>
			</div>
			<div id="/section-9/page-4" class="ft-page page-55 right-img" data-id="page-4">
				<img src='img/14915.jpg' />
				<p class="text">
					<span id="text-73" contenteditable="true">小明和小红的故事会一直继续下去。</span><br />
					<span id="text-74" contenteditable="true">无论精彩、平淡都会是他们喜欢的。</span><br />
					<br />
					<br />
					<span> -- 按“Esc"键有惊喜</span>
				</p>				
			</div>
		</div>
	</div>
	<div class="nojavascript">您的浏览器禁用了javascript，无法正常浏览本页面</div>
	<div class="write-tip">
		<span class="showtip">小提示：点击文字可以进行编辑，点击右下角心形可以跳跃浏览</span>
		<span style="display:none">小提示：编辑完成后点击保存修改，发送给你的亲亲开始表白吧</span>
		<button id="write-submit">保存修改</button>
	</div>
	<div class="write-ok">
		<div class="write-box">
			<h2>还差一步即可生成表白页面</h2>
			<p id="write-mp3">自定义背景音乐：<span id="text-music" contenteditable="true">http://<?php echo $_SERVER['HTTP_HOST']; ?>/love/music/saveme</span><i></i>.mp3</p>
			<p id="write-url">自定义表白链接：<u>http://<?php echo $_SERVER['HTTP_HOST']; ?>/love/2014/</u><span id="text-href" contenteditable="true"><?php echo time(); ?></span><i></i><u>.html</u></p>
			<p><small>自定义链接名只能为3-30位的字母[a-zA-Z]、数字[0-9]、- 和 _ </small></p>
			<small><a href="###" id="back">重新修改</a></small> <button id="write-post">❤ 生成表白页面</button>
			<div class="write-share">
				<p>~\(≧▽≦)/~ 点击分享 发送给你的亲亲吧</p>
				<div class="bdsharebuttonbox"><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a><a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧"></a><a href="#" class="bds_copy" data-cmd="copy" title="分享到复制网址"></a><a href="#" class="bds_more" data-cmd="more"></a></div>
			</div>
		</div>
	</div>

	<audio id="bgmMusic" src="music/saveme.mp3" autoplay="autoplay" loop="loop" preload="auto" type="audio/mp3"></audio>
    
	<script src="http://libs.baidu.com/jquery/1.8.3/jquery.min.js"></script>
	<script src="js/all.min.js"></script>
	<script src="js/love.min.js"></script>
    <div class="mPower"><span id="on" title="点击暂停"></span><span id="off" title="点击播放"></span></div>
</body>
</html>
